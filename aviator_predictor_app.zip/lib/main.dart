
import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(const AviatorBotApp());
}

class AviatorBotApp extends StatelessWidget {
  const AviatorBotApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aviator Predictor',
      theme: ThemeData(
        primarySwatch: Colors.red,
        useMaterial3: true,
      ),
      home: const AviatorHomePage(),
    );
  }
}

class AviatorHomePage extends StatefulWidget {
  const AviatorHomePage({super.key});

  @override
  State<AviatorHomePage> createState() => _AviatorHomePageState();
}

class _AviatorHomePageState extends State<AviatorHomePage> {
  final TextEditingController _controller = TextEditingController();
  double? _predictedMultiplier;
  String? _suggestion;

  void _predict(double tempoVoo) {
    // Modelo de regressão linear simples: multiplicador = tempo * 0.25 + ruído
    final random = Random();
    double ruido = random.nextDouble() * 0.5; // ruído aleatório
    double multiplicador = tempoVoo * 0.25 + ruido;

    setState(() {
      _predictedMultiplier = double.parse(multiplicador.toStringAsFixed(2));
      _suggestion = multiplicador >= 2.0 ? 'Apostar ✅' : 'Não Apostar ❌';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bot Previsor Aviator'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Digite o tempo de voo (segundos):',
              style: TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _controller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Tempo de Voo',
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                double? tempo = double.tryParse(_controller.text);
                if (tempo != null) {
                  _predict(tempo);
                }
              },
              child: const Text('Calcular'),
            ),
            const SizedBox(height: 30),
            if (_predictedMultiplier != null && _suggestion != null) ...[
              Text('Multiplicador Previsto: $_predictedMultiplier',
                  style: const TextStyle(fontSize: 20)),
              const SizedBox(height: 10),
              Text('Sugestão: $_suggestion',
                  style: TextStyle(
                      fontSize: 22,
                      color: _suggestion == 'Apostar ✅'
                          ? Colors.green
                          : Colors.red)),
            ],
          ],
        ),
      ),
    );
  }
}
